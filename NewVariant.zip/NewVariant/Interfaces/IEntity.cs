namespace NewVariant.Interfaces; 

public interface IEntity {
    public int Id { get; }
}